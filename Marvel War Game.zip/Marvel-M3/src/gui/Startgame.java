package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.Disarm;
import model.effects.Effect;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Condition;
import model.world.Cover;
import model.world.Direction;
import model.world.Hero;
import engine.Game;
import engine.Player;
import engine.PriorityQueue;
import exceptions.AbilityUseException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;

public class Startgame extends JFrame {
	private JButton startB;
	private JButton button = new JButton();
	private JPanel panel;
	private JLabel label;
	private Game game;
	private ArrayList<JButton> Champbtns;
	private JLabel labelP1;
	private JLabel labelP2;
	private Player player1;
	private Player player2;
	private JTextArea txtChampions2;
	private JTextArea txtChampions1;
	private JPanel pnlChampions;
	private ImageIcon display;
	private JPanel p1l = new JPanel();
	private JPanel board = new JPanel();
	private JButton[][] boardbtn;
	private JButton ab1;
	private JButton ab2;
	private JButton ab3;
	private JButton ab4;
	private Champion cur;
	private ArrayList<Ability> a;
	private JTextArea txtp1;
	private JTextArea txtp2;
	private JLabel turntext;
	private PriorityQueue turnorder1;

	public Startgame() {
		ImageIcon logo = new ImageIcon("marvel-logo.png");

		setIconImage(logo.getImage());
		startB = new JButton("Start Game");
		startB.setSize(100, 50);
		
		 startB.setBounds(600, 650, 100, 50);
		startB.setFocusable(false);
		startB.addActionListener(e -> {
			try {
				startActionB();
			} catch (Exception e1) {

				
			}
		});
		getContentPane().setBackground(Color.red);
		display = new ImageIcon("marvel display.jpg");
		Border border = BorderFactory.createLineBorder(Color.black, 4);
		label = new JLabel();
		label.setText("Marvel: Ultimate War");
		label.setIcon(display);
		label.setHorizontalTextPosition(JLabel.CENTER);
		label.setVerticalTextPosition(JLabel.TOP);
		label.setVerticalAlignment(JLabel.TOP);
		label.setHorizontalAlignment(JLabel.CENTER);
		label.setForeground(Color.white);
		label.setFont(new Font("san serif", Font.BOLD, 20));
		label.setBackground(Color.BLACK); 
		label.setOpaque(true); 
		label.setBorder(border);
		panel = new JPanel();
		panel.setLayout(new BorderLayout());
		label.add(startB);
		startB.setVerticalAlignment(JLabel.BOTTOM);
		startB.setHorizontalAlignment(JLabel.CENTER);
		panel.add(label);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setSize(1500, 750);
		setTitle("Marvel: Ultimate War");
		setLayout(new BorderLayout());
		setSize(getMaximumSize());
		
		add(panel);


	}

	public void startActionB() throws IOException {
		label.remove(startB);

		JTextField firstP = new JTextField();
		JTextField secondP = new JTextField();
		labelP1 = new JLabel();
		labelP2 = new JLabel();
		labelP1.setText("Player 1 Name");
		labelP2.setText("Player 2 Name");
		labelP1.setBounds(150, 400, 300, 100);
		
		 labelP2.setBounds(900, 400, 300, 100);
		labelP1.setForeground(Color.white);
		labelP2.setForeground(Color.white);
		labelP1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
		labelP2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));

		firstP.setBounds(100, 500, 300, 100);
		firstP.requestFocus();
		
		 secondP.setBounds(850, 500, 300, 100);
		secondP.requestFocus();
		label.add(firstP);
		label.add(secondP);
		button.setText("Lessssgo");
		button.setSize(100, 50);
		
		 button.setBounds(600, 650, 100, 50);
		button.setFocusable(false);
		button.addActionListener(e -> {
			if (e.getSource() == button)
				if (firstP.getText().equals("") || secondP.getText().equals("")) {
					JOptionPane.showMessageDialog(this,
							" please enter player 1 and player 2 names ",
							"Player Names", JOptionPane.PLAIN_MESSAGE);
				} else {
					try {
						lesgoActionB(firstP.getText(), secondP.getText());
					} catch (Exception e1) {
					
					}

				}
		});

		label.add(button);
		label.add(labelP1);
		label.add(labelP2);
		
		this.revalidate();
		this.repaint();
		
	}

	public void lesgoActionB(String firstP, String secondP) throws IOException {
		this.remove(panel);
		panel.removeAll();
		ArrayList<String> Champions1 = new ArrayList<>();
		ArrayList<String> Champions2 = new ArrayList<>();
		
		pnlChampions = new JPanel();
		pnlChampions.setLayout(new GridLayout(3, 0));
		pnlChampions.setBounds(600, 0, 500, getHeight());
		this.add(pnlChampions);

		txtChampions1 = new JTextArea();
		txtChampions1.setPreferredSize(new Dimension(200, getHeight()));
		txtChampions1.setEditable(false);
		txtChampions1.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
		add(txtChampions1, BorderLayout.WEST);

		txtChampions2 = new JTextArea();
		txtChampions2.setPreferredSize(new Dimension(200, getHeight()));
		txtChampions2.setEditable(false);
		txtChampions2.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
		add(txtChampions2, BorderLayout.EAST);

		String team1 = firstP;
		team1 += " Champions:\n";
		team1 += "'''''''\n";

		for (String s : Champions1) {
			team1 += "-" + s + "\n";
		}
		if (!Champions1.isEmpty()) {
			team1 += "*************** \n";
		}

		String team2 = secondP;
		team2 += " Champions:\n";
		team2 += "'''''''\n";

		for (String s : Champions2) {
			team2 += "-" + s + "\n";
		}
		if (!Champions2.isEmpty()) {
			team2 += "*************** \n";
		}
		team1 += String.format("Champions:       \n");
		txtChampions1.setText(team1);

		team2 += String.format("Champions:       \n");
		txtChampions2.setText(team2);
		

		panel.setBackground(Color.black);
		panel.setLayout(new GridLayout(5, 5));
		Champbtns = new ArrayList<>();
		player1 = new Player(firstP);
		player2 = new Player(secondP);
		game = new Game(player1, player2);
		Game.loadAbilities("Abilities.csv");
		Game.loadChampions("Champions.csv");
		
		for (Champion c : game.getAvailableChampions()) {
			JButton Champbtn = new JButton(c.getName());
			Champbtn.addActionListener(e -> {
				Champbtn.setEnabled(false);
				if (player1.getTeam().size() == 3
						&& player2.getTeam().size() == 2) {
					player2.getTeam().add(c);
					txtChampions2.setText(txtChampions2.getText() + "\n"
							+ c.getName());
					selectLeader1();
				} else if (player2.getTeam().size() == player1.getTeam().size()) {
					player1.getTeam().add(c);
					txtChampions1.setText(txtChampions1.getText() + "\n"
							+ c.getName());
				} else {
					player2.getTeam().add(c);
					txtChampions2.setText(txtChampions2.getText() + "\n"
							+ c.getName());
				}

			});
			Champbtns.add(Champbtn);
			
			this.setVisible(true);
		}

		for (JButton j : Champbtns) {
			pnlChampions.add(j);
			this.revalidate();
			this.repaint();
			this.setVisible(true);
		}
		for (int i = 0; i < Champbtns.size(); i++) {
			String s = "<html>";
			s = s
					+ "MaxHP: "
					+ game.getAvailableChampions().get(i).getMaxHP()
					+ "<br>"
					+ "Speed: "
					+ game.getAvailableChampions().get(i).getSpeed()
					+ "<br>"
					+ "Mana: "
					+ game.getAvailableChampions().get(i).getMana()
					+ "<br>"
					+ "Action Points: "
					+ game.getAvailableChampions().get(i)
							.getMaxActionPointsPerTurn() + "<br>"
					+ "Attack Range: "
					+ game.getAvailableChampions().get(i).getAttackRange()
					+ "<br>" + "Attack Damage: "
					+ game.getAvailableChampions().get(i).getAttackDamage()
					+ "<br>" + "Abilities: ";
			for (int j = 1; j <= game.getAvailableChampions().get(i)
					.getAbilities().size(); j++) {
				s = s
						+ "<br>"
						+ j
						+ ") "
						+ game.getAvailableChampions().get(i).getAbilities()
								.get(j - 1).getName();
			}
			Champbtns.get(i).setToolTipText(s);
		}

		this.revalidate();
		this.repaint();
		this.setVisible(true);
	}

	public void selectLeader1() {
		this.remove(pnlChampions);
		this.remove(txtChampions1);
		this.remove(txtChampions2);
		
		panel.removeAll();
		panel.setLayout(new GridLayout(4, 0));
		label.setText(player1.getName() + "! Please choose your leader");
		JButton p1b1 = new JButton(player1.getTeam().get(0).getName());
		p1b1.addActionListener(e -> {
			player1.setLeader(player1.getTeam().get(0));
			selectLeader2();
		});
		JButton p1b2 = new JButton(player1.getTeam().get(1).getName());
		p1b2.addActionListener(e -> {
			player1.setLeader(player1.getTeam().get(1));
			selectLeader2();
		});
		JButton p1b3 = new JButton(player1.getTeam().get(2).getName());
		p1b3.addActionListener(e -> {
			player1.setLeader(player1.getTeam().get(2));
			selectLeader2();
		});
		panel.add(label);
		panel.add(p1b1);
		panel.add(p1b2);
		panel.add(p1b3);
		this.add(panel);
		this.revalidate();
		this.repaint();

	}

	public void selectLeader2() {
		panel.removeAll();
		panel.setLayout(new GridLayout(4, 0));
		label.setText(player2.getName() + "! Please choose your leader");
		JButton p2b1 = new JButton(player2.getTeam().get(0).getName());
		p2b1.addActionListener(e -> {
			player2.setLeader(player2.getTeam().get(0));
			board();
		});
		JButton p2b2 = new JButton(player2.getTeam().get(1).getName());
		p2b2.addActionListener(e -> {
			player2.setLeader(player2.getTeam().get(1));
			board();
		});
		JButton p2b3 = new JButton(player2.getTeam().get(2).getName());
		p2b3.addActionListener(e -> {
			player2.setLeader(player2.getTeam().get(2));
			board();
		});
		panel.add(label);
		panel.add(p2b1);
		panel.add(p2b2);
		panel.add(p2b3);
		add(panel);
		this.revalidate();
		this.repaint();
	}

	public void update() {
		if (game.checkGameOver() != null)
			gameOver();
		
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				if (game.getBoard()[i][j] != null) {
					if (game.getBoard()[i][j] instanceof Cover) {
						boardbtn[i][j].setText("<html> Cover "
								+ "<br> Current HP: "
								+ ((Cover) game.getBoard()[i][j])
										.getCurrentHP());
					} else {
						if (((Champion) game.getBoard()[i][j]).getCurrentHP() <= 0
								|| ((Champion) game.getBoard()[i][j])
										.getCondition() == Condition.KNOCKEDOUT) {
							boardbtn[i][j].setText(null);
							boardbtn[i][j].setBackground(Color.white);
							game.getFirstPlayer().getTeam()
									.remove(((Champion) game.getBoard()[i][j]));
							game.getSecondPlayer().getTeam()
									.remove(((Champion) game.getBoard()[i][j]));
							if (game.checkGameOver() != null)
								gameOver();
						}

						else {
							boardbtn[i][j].setText("<html>"
									+ ((Champion) game.getBoard()[i][j])
											.getName()
									+ "<br> Current HP:"
									+ ((Champion) game.getBoard()[i][j])
											.getCurrentHP());
							if (game.getBoard()[i][j].equals(game
									.getCurrentChampion())) {
								boardbtn[i][j].setBackground(Color.GREEN);
								boardbtn[i][j].setOpaque(true);
							}
						}
					}
				} else {
					boardbtn[i][j].setText(null);
					boardbtn[i][j].setBackground(Color.white);
				}
			}
		}

		String p1 = player1.getName() + "\n" + "\n" + "Leader Ability Used: "
				+ game.isFirstLeaderAbilityUsed() + "\n";
		String ab = "";
		String ef = "";
		
		p1 += " Champions:\n";

		for (Champion c : player1.getTeam()) {
			p1 += c.getName();
			if (c.equals(player1.getLeader()))
				p1 += " Leader";
			p1 += "\n";
		}

		Champion s = game.getCurrentChampion();
		if (player1.getTeam().contains(s)) {
			for (Ability a : s.getAbilities()) {
				ab += "\n" + a.getName() + "\n" + "Base Cooldown: "
						+ a.getBaseCooldown() + "\n" + "Cast Range: "
						+ a.getCastRange() + "\n" + "Current Cooldown: "
						+ a.getCurrentCooldown() + "\n" + "Mana Cost: "
						+ a.getManaCost() + "\n" + "Required Action Points: "
						+ a.getRequiredActionPoints() + "\n" + "Cast Area: "
						+ a.getCastArea() + "\n" + "Type: "
						+ a.getClass().getSimpleName() + "\n";
				if (a instanceof HealingAbility) {
					ab += "Healing Amount: "
							+ ((HealingAbility) a).getHealAmount() + "\n";
				} else if (a instanceof DamagingAbility)
					ab += "Damage Amount: "
							+ ((DamagingAbility) a).getDamageAmount() + "\n";
				else
					ab += "Effect: "
							+ ((CrowdControlAbility) a).getEffect().getName()
							+ "\n";

			}
			for (Effect e : s.getAppliedEffects()) {

				ef += e.getName() + " " + e.getDuration() + "\n";
			}
			p1 += "-" + s.getName() + ":  \n" + "Type: "
					+ s.getClass().getSimpleName() + "\n" + "Health:"
					+ s.getCurrentHP() + "\n" + "Action Points:"
					+ s.getCurrentActionPoints() + "\n" + "Mana:" + s.getMana()
					+ "\n" + "Attack Range:" + s.getAttackRange() + "\n"
					+ "Attack Damage: " + s.getAttackDamage() + "\n"
					+ "Speed: " + s.getSpeed() + "\n" + "Abilities: \n" + ab
					+ "\n" + "Effects: " + ef + "\n";

		}
		txtp1.setText(p1);

		
		String p2 = player2.getName() + "\n" + "\n" + "Leader Ability Used: "
				+ game.isSecondLeaderAbilityUsed() + "\n";
		
		p2 += "Champions:\n";
		for (Champion c : player2.getTeam()) {
			p2 += c.getName();
			if (c.equals(player2.getLeader()))
				p2 += " Leader";
			p2 += "\n";
		}

		if (player2.getTeam().contains(s)) {
			for (Ability a : s.getAbilities()) {
				ab += "\n" + a.getName() + "\n" + "Base Cooldown: "
						+ a.getBaseCooldown() + "\n" + "Cast Range: "
						+ a.getCastRange() + "\n" + "Current Cooldown: "
						+ a.getCurrentCooldown() + "\n" + "Mana Cost: "
						+ a.getManaCost() + "\n" + "Required Action Points: "
						+ a.getRequiredActionPoints() + "\n" + "Cast Area: "
						+ a.getCastArea() + "\n" + "Type: "
						+ a.getClass().getSimpleName() + "\n";
				if (a instanceof HealingAbility) {
					ab += "Healing Amount: "
							+ ((HealingAbility) a).getHealAmount() + "\n";
				} else if (a instanceof DamagingAbility)
					ab += "Damage Amount: "
							+ ((DamagingAbility) a).getDamageAmount() + "\n";
				else
					ab += "Effect: "
							+ ((CrowdControlAbility) a).getEffect().getName()
							+ "\n";

			}
			for (Effect e : s.getAppliedEffects()) {

				ef += e.getName() + " " + e.getDuration() + "\n";
			}
			p2 += "-" + s.getName() + ":  \n" + "Type: "
					+ s.getClass().getSimpleName() + "\n" + "Health:"
					+ s.getCurrentHP() + "\n" + "Action Points:"
					+ s.getCurrentActionPoints() + "\n" + "Mana:" + s.getMana()
					+ "\n" + "Attack Range:" + s.getAttackRange() + "\n"
					+ "Attack Damage: " + s.getAttackDamage() + "\n"
					+ "Speed: " + s.getSpeed() + "\n" + "Abilities: \n" + ab
					+ "\n" + "Effects: " + ef + "\n";
		}
		txtp2.setText(p2);
		for (int i = 4; i >= 0; i--) {
			for (int j = 0; j < 5; j++) {
				if (game.getBoard()[i][j] != null) {
					if (game.getBoard()[i][j] instanceof Champion) {
						String z= "<html>";
						if(game.getBoard()[i][j] instanceof Hero) {
							z= z+ "Type: Hero";
						}
						else if(game.getBoard()[i][j] instanceof AntiHero) {
							z= z+ "Type: AntiHero";
						}
						else z= z+ "Type: Villain";
						z=  z +
								"<br>"
						        +"MaxHP: "
								+ ((Champion) game.getBoard()[i][j]).getMaxHP()
								+ "<br>"
								+ "Speed: "
								+ ((Champion) game.getBoard()[i][j]).getSpeed()
								+ "<br>"
								+ "Mana: "
								+ ((Champion) game.getBoard()[i][j]).getMana()
								+ "<br>"
								+ "Action Points: "
								+ ((Champion) game.getBoard()[i][j])
										.getMaxActionPointsPerTurn() + "<br>"
								+ "Attack Range: "
								+ ((Champion) game.getBoard()[i][j]).getAttackRange()
								+ "<br>" + "Attack Damage: "
								+ ((Champion) game.getBoard()[i][j]).getAttackDamage()
								+ "<br>" +
								"Condition: "+
								((Champion) game.getBoard()[i][j]).getCondition()
								+"<br>"
								+ "Abilities: ";
						for (int j1 = 1; j1 <= ((Champion) game.getBoard()[i][j]).getAbilities().size(); j1++) {
							z = z  + "<br>"
									+ j1
									+ ") "
									+ ((Champion) game.getBoard()[i][j]).getAbilities()
											.get(j1 - 1).getName();
						}
						z= z+ "<br>"+ "Applied Effects: ";
						for(int j2 = 1; j2 <= ((Champion) game.getBoard()[i][j]).getAppliedEffects().size(); j2++) {
							z = z
									+ "<br>"
									+ j2
									+ ") "
									+ ((Champion) game.getBoard()[i][j]).getAppliedEffects()
											.get(j2 - 1).getName();
						}
						(boardbtn[i][j]).setToolTipText(z);
					}
				}
			}
		}

		panel.add(txtp1, BorderLayout.WEST);
		panel.add(txtp2, BorderLayout.EAST);
		
		String s1= "";
		turnorder1= new PriorityQueue(game.getTurnOrder().size());
		Champion c=(Champion) game.getTurnOrder().remove();
		
		while(!game.getTurnOrder().isEmpty()) {
			s1= s1+ ", "+((Champion)game.getTurnOrder().peekMin()).getName();
			turnorder1.insert(game.getTurnOrder().remove());
		}
		while(!turnorder1.isEmpty()) {
			game.getTurnOrder().insert(turnorder1.remove());
		}
		game.getTurnOrder().insert(c);
		turntext.setText("Next Champion: "+s1);
		
		cur = game.getCurrentChampion();
		a = cur.getAbilities();
	}

	public void board() {
		panel.removeAll();
		panel.setLayout(new BorderLayout());
		game.prepareChampionTurns();
		game.placeChampions();

		board.setBounds(200, 0, 1200, getHeight() - 250);
		panel.add(board, BorderLayout.CENTER);
		board.setLayout(new GridLayout(5, 5));
		boardbtn = new JButton[5][5];
		for (int i = 4; i >= 0; i--) {
			for (int j = 0; j < 5; j++) {
				JButton cell = new JButton();
				boardbtn[i][j] = cell;
				boardbtn[i][j].setBackground(Color.WHITE);
				boardbtn[i][j].setSize(200, 100);
				boardbtn[i][j].setEnabled(false);
				board.add(boardbtn[i][j]);
			}
		}
		txtp1 = new JTextArea();
		txtp1.setPreferredSize(new Dimension(200, getHeight()));
		txtp1.setEditable(false);
		txtp1.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
		txtp1.setBackground(Color.white);

		txtp2 = new JTextArea();
		txtp2.setPreferredSize(new Dimension(200, getHeight()));
		txtp2.setEditable(false);
		txtp2.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
		txtp2.setBackground(Color.white);

		
		String p1 = player1.getName() + "\n" + "\n" + "Leader Ability Used: "
				+ game.isFirstLeaderAbilityUsed() + "\n";
		String ab = "";
		String ef = "";
		
		p1 += " Champions:\n";
		for (Champion c : player1.getTeam()) {
			p1 += c.getName();
			if (c.equals(player1.getLeader()))
				p1 += " Leader";
			p1 += "\n";
		}

		Champion s = game.getCurrentChampion();
		if (player1.getTeam().contains(s)) {
			for (Ability a : s.getAbilities()) {
				ab += "\n" + a.getName() + "\n" + "Base Cooldown: "
						+ a.getBaseCooldown() + "\n" + "Cast Range: "
						+ a.getCastRange() + "\n" + "Current Cooldown: "
						+ a.getCurrentCooldown() + "\n" + "Mana Cost: "
						+ a.getManaCost() + "\n" + "Required Action Points: "
						+ a.getRequiredActionPoints() + "\n" + "Cast Area: "
						+ a.getCastArea() + "\n" + "Type: "
						+ a.getClass().getSimpleName() + "\n";
				if (a instanceof HealingAbility) {
					ab += "Healing Amount: "
							+ ((HealingAbility) a).getHealAmount() + "\n";
				} else if (a instanceof DamagingAbility)
					ab += "Damage Amount: "
							+ ((DamagingAbility) a).getDamageAmount() + "\n";
				else
					ab += "Effect: "
							+ ((CrowdControlAbility) a).getEffect().getName()
							+ "\n";

			}
			for (Effect e : s.getAppliedEffects()) {

				ef += e.getName() + " " + e.getDuration() + "\n";
			}
			p1 += "-" + s.getName() + ":  \n" + "Type: "
					+ s.getClass().getSimpleName() + "\n" + "Health:"
					+ s.getCurrentHP() + "\n" + "Action Points:"
					+ s.getCurrentActionPoints() + "\n" + "Mana:" + s.getMana()
					+ "\n" + "Attack Range:" + s.getAttackRange() + "\n"
					+ "Attack Damage: " + s.getAttackDamage() + "\n"
					+ "Speed: " + s.getSpeed() + "\n" + "Abilities: \n" + ab
					+ "\n" + "Effects: " + ef + "\n";
		}
		txtp1.setText(p1);
		

		String p2 = player2.getName() + "\n" + "\n" + "Leader Ability Used: "
				+ game.isSecondLeaderAbilityUsed() + "\n";
		
		p2 += "Champions:\n";
		for (Champion c : player2.getTeam()) {
			p2 += c.getName();
			if (c.equals(player2.getLeader()))
				p2 += " Leader";
			p2 += "\n";
		}

		if (player2.getTeam().contains(s)) {
			for (Ability a : s.getAbilities()) {
				ab += "\n" + a.getName() + "\n" + "Base Cooldown: "
						+ a.getBaseCooldown() + "\n" + "Cast Range: "
						+ a.getCastRange() + "\n" + "Current Cooldown: "
						+ a.getCurrentCooldown() + "\n" + "Mana Cost: "
						+ a.getManaCost() + "\n" + "Required Action Points: "
						+ a.getRequiredActionPoints() + "\n" + "Cast Area: "
						+ a.getCastArea() + "\n" + "Type: "
						+ a.getClass().getSimpleName() + "\n";
				if (a instanceof HealingAbility) {
					ab += "Healing Amount: "
							+ ((HealingAbility) a).getHealAmount() + "\n";
				} else if (a instanceof DamagingAbility)
					ab += "Damage Amount: "
							+ ((DamagingAbility) a).getDamageAmount() + "\n";
				else
					ab += "Effect: "
							+ ((CrowdControlAbility) a).getEffect().getName()
							+ "\n";

			}
			for (Effect e : s.getAppliedEffects()) {

				ef += e.getName() + " " + e.getDuration() + "\n";
			}
			p2 += "-" + s.getName() + ":  \n" + "Type: "
					+ s.getClass().getSimpleName() + "\n" + "Health:"
					+ s.getCurrentHP() + "\n" + "Action Points:"
					+ s.getCurrentActionPoints() + "\n" + "Mana:" + s.getMana()
					+ "\n" + "Attack Range:" + s.getAttackRange() + "\n"
					+ "Attack Damage: " + s.getAttackDamage() + "\n"
					+ "Speed: " + s.getSpeed() + "\n" + "Abilities: \n" + ab
					+ "\n" + "Effects: " + ef + "\n";
		}
		txtp2.setText(p2);
		panel.add(txtp1, BorderLayout.WEST);
		panel.add(txtp2, BorderLayout.EAST);

		for (int i = 4; i >= 0; i--) {
			for (int j = 0; j < 5; j++) {
				if (game.getBoard()[i][j] != null) {
					if (game.getBoard()[i][j] instanceof Cover) {
						boardbtn[i][j].setBackground(Color.orange);
						boardbtn[i][j].setText("<html> Cover "
								+ "<br> Current HP: "
								+ ((Cover) game.getBoard()[i][j])
										.getCurrentHP());

						
					} else {
						boardbtn[i][j].setBackground(Color.red);
						boardbtn[i][j].setText("<html>"
								+ ((Champion) game.getBoard()[i][j]).getName()
								+ "<br> Current HP: "
								+ ((Champion) game.getBoard()[i][j])
										.getCurrentHP());
						
						if (game.getBoard()[i][j].equals(game
								.getCurrentChampion())) {
							boardbtn[i][j].setBackground(Color.GREEN);
							boardbtn[i][j].setOpaque(true);
						}
					}
				}
			}
		}
		for (int i = 4; i >= 0; i--) {
			for (int j = 0; j < 5; j++) {
				if (game.getBoard()[i][j] != null) {
					if (game.getBoard()[i][j] instanceof Champion) {
						String z= "<html>";
						if(game.getBoard()[i][j] instanceof Hero) {
							z= z+ "Type: Hero";
						}
						else if(game.getBoard()[i][j] instanceof AntiHero) {
							z= z+ "Type: AntiHero";
						}
						else z= z+ "Type: Villain";
						z=  z +
								"<br>"
						        +"MaxHP: "
								+ ((Champion) game.getBoard()[i][j]).getMaxHP()
								+ "<br>"
								+ "Speed: "
								+ ((Champion) game.getBoard()[i][j]).getSpeed()
								+ "<br>"
								+ "Mana: "
								+ ((Champion) game.getBoard()[i][j]).getMana()
								+ "<br>"
								+ "Action Points: "
								+ ((Champion) game.getBoard()[i][j])
										.getMaxActionPointsPerTurn() + "<br>"
								+ "Attack Range: "
								+ ((Champion) game.getBoard()[i][j]).getAttackRange()
								+ "<br>" + "Attack Damage: "
								+ ((Champion) game.getBoard()[i][j]).getAttackDamage()
								+ "<br>" +
								"Condition: "+
								((Champion) game.getBoard()[i][j]).getCondition()
								+"<br>"
								+ "Abilities: ";
						for (int j1 = 1; j1 <= ((Champion) game.getBoard()[i][j]).getAbilities().size(); j1++) {
							z = z  + "<br>"
									+ j1
									+ ") "
									+ ((Champion) game.getBoard()[i][j]).getAbilities()
											.get(j1 - 1).getName();
						}
						z= z+ "<br>"+ "Applied Effects: ";
						for(int j2 = 1; j2 <= ((Champion) game.getBoard()[i][j]).getAppliedEffects().size(); j2++) {
							z = z
									+ "<br>"
									+ j2
									+ ") "
									+ ((Champion) game.getBoard()[i][j]).getAppliedEffects()
											.get(j2 - 1).getName();
						}
						(boardbtn[i][j]).setToolTipText(z);
					}
				}
			}
		}
		JButton attack = new JButton();
		attack.setText("Attack");
		attack.setPreferredSize(new Dimension(100, 100));
		attack.setBounds(350, board.getHeight(), 100, 100);
		attack.addActionListener(e -> {
			JFrame attackF = new JFrame();
			attackF.setSize(500, 500);
			attackF.setVisible(true);
			attackF.setLayout(new GridLayout(2, 2));
			JButton attackUP = new JButton("Attack UP");
			attackUP.addActionListener(u -> {
				try {
					game.attack(Direction.UP);
					update();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Attack Cannot be preformed",
							JOptionPane.ERROR_MESSAGE);
				}
			});

			JButton attackDOWN = new JButton("Attack DOWN");
			attackDOWN.addActionListener(d -> {
				try {
					game.attack(Direction.DOWN);
					update();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Attack Cannot be preformed",
							JOptionPane.ERROR_MESSAGE);

				}
			});
			JButton attackRIGHT = new JButton("Attack RIGHT");
			attackRIGHT.addActionListener(l -> {
				try {
					game.attack(Direction.RIGHT);
					update();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Attack Cannot be preformed",
							JOptionPane.ERROR_MESSAGE);
				}

			});
			JButton attackLEFT = new JButton("Attack LEFT");
			attackLEFT.addActionListener(u -> {
				try {
					game.attack(Direction.LEFT);
					update();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Attack Cannot be preformed",
							JOptionPane.ERROR_MESSAGE);

				}

			});

			attackF.add(attackUP);
			attackF.add(attackDOWN);
			attackF.add(attackRIGHT);
			attackF.add(attackLEFT);

		});

		JButton move = new JButton();
		move.setText("Move");
		move.setPreferredSize(new Dimension(100, 100));
		move.setBounds(200, board.getHeight(), 100, 100);
		move.addActionListener(e -> {
			JFrame moveF = new JFrame();
			moveF.setSize(500, 500);
			moveF.setVisible(true);
			moveF.setLayout(new GridLayout(2, 2));
			JButton moveUP = new JButton("Move UP");
			moveUP.addActionListener(u -> {
				try {

					int cxold = game.getCurrentChampion().getLocation().x;
					int cyold = game.getCurrentChampion().getLocation().y;

					game.move(Direction.UP);
					boardbtn[cxold][cyold].setText(null);
					boardbtn[cxold][cyold].setBackground(Color.white);
					int cxnew = game.getCurrentChampion().getLocation().x;
					int cynew = game.getCurrentChampion().getLocation().y;
					boardbtn[cxnew][cynew].setText("<html>"
							+ game.getCurrentChampion().getName()
							+ "<br> Current HP: "
							+ game.getCurrentChampion().getCurrentHP());
					boardbtn[cxnew][cynew].setBackground(Color.green);
					this.update();

				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Movement Cannot be preformed",
							JOptionPane.ERROR_MESSAGE);
				}
			});

			moveF.add(moveUP);
			JButton moveDown = new JButton("Move Down");
			moveDown.addActionListener(u -> {
				try {
					int cxold = game.getCurrentChampion().getLocation().x;
					int cyold = game.getCurrentChampion().getLocation().y;

					game.move(Direction.DOWN);
					boardbtn[cxold][cyold].setText(null);
					boardbtn[cxold][cyold].setBackground(Color.white);
					int cxnew = game.getCurrentChampion().getLocation().x;
					int cynew = game.getCurrentChampion().getLocation().y;
					boardbtn[cxnew][cynew].setText("<html>"
							+ game.getCurrentChampion().getName()
							+ "<br> Current HP: "
							+ game.getCurrentChampion().getCurrentHP());
					boardbtn[cxnew][cynew].setBackground(Color.green);
					this.update();

				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Movement Cannot be preformed",
							JOptionPane.ERROR_MESSAGE);
				}
			});

			moveF.add(moveDown);
			JButton moveLeft = new JButton("Move Left");
			moveLeft.addActionListener(u -> {
				try {
					int cxold = game.getCurrentChampion().getLocation().x;
					int cyold = game.getCurrentChampion().getLocation().y;

					game.move(Direction.LEFT);
					boardbtn[cxold][cyold].setText(null);
					boardbtn[cxold][cyold].setBackground(Color.white);
					int cxnew = game.getCurrentChampion().getLocation().x;
					int cynew = game.getCurrentChampion().getLocation().y;
					boardbtn[cxnew][cynew].setText("<html>"
							+ game.getCurrentChampion().getName()
							+ "<br> Current HP: "
							+ game.getCurrentChampion().getCurrentHP());
					boardbtn[cxnew][cynew].setBackground(Color.green);
					this.update();

				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Movement Cannot be preformed",
							JOptionPane.ERROR_MESSAGE);
				}
			});

			moveF.add(moveLeft);
			JButton moveRight = new JButton("Move Right");
			moveRight.addActionListener(u -> {
				try {
					int cxold = game.getCurrentChampion().getLocation().x;
					int cyold = game.getCurrentChampion().getLocation().y;

					game.move(Direction.RIGHT);
					boardbtn[cxold][cyold].setText(null);
					boardbtn[cxold][cyold].setBackground(Color.white);
					int cxnew = game.getCurrentChampion().getLocation().x;
					int cynew = game.getCurrentChampion().getLocation().y;
					boardbtn[cxnew][cynew].setText("<html>"
							+ game.getCurrentChampion().getName()
							+ "<br> Current HP: "
							+ game.getCurrentChampion().getCurrentHP());
					boardbtn[cxnew][cynew].setBackground(Color.green);
					this.update();

				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Movement Cannot be preformed",
							JOptionPane.ERROR_MESSAGE);
				}
			});
			moveF.add(moveRight);

		});
		cur = game.getCurrentChampion();
		a = cur.getAbilities();
		ab1 = new JButton(a.get(0).getName());
		ab1.setPreferredSize(new Dimension(100, 100));
		ab1.setBounds(500, board.getHeight(), 100, 100);
		ab1.addActionListener(a1 -> {
			if (a.get(0).getCastArea().equals(AreaOfEffect.TEAMTARGET)
					|| a.get(0).getCastArea().equals(AreaOfEffect.SELFTARGET)
					|| (a.get(0).getCastArea().equals(AreaOfEffect.SURROUND))) {

				try {
					game.castAbility(a.get(0));
					update();

				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Not Enough Resources Exception",
							JOptionPane.ERROR_MESSAGE);
				} catch (AbilityUseException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Ability Used Exception", JOptionPane.ERROR_MESSAGE);
				} catch (CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Clone Not Supported Exception",
							JOptionPane.ERROR_MESSAGE);
				}

			}
			if (a.get(0).getCastArea().equals(AreaOfEffect.DIRECTIONAL)) {

				JFrame Directions = new JFrame("Directions");
				Directions.setPreferredSize(new Dimension(500, 500));
				Directions.setSize(500, 500);
				Directions.setTitle("Direction of Ability");
				Directions.setLayout(new GridLayout(2, 2));
				Directions.setVisible(true);
				System.out.println("dakhal");
				JButton AbilityR = new JButton("Right");
				AbilityR.addActionListener(d -> {
					try {
						game.castAbility(a.get(0), Direction.RIGHT);
						update();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Not Enough Resources Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Ability Used Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Clone Not Supported Exception",
								JOptionPane.ERROR_MESSAGE);
					}

				});
				
				Directions.add(AbilityR);

				JButton AbilityL = new JButton("Left");
				AbilityL.addActionListener(l -> {
					try {
						game.castAbility(a.get(0), Direction.LEFT);
						update();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Not Enough Resources Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Ability Used Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Clone Not Supported Exception",
								JOptionPane.ERROR_MESSAGE);
					}

				});
				
				Directions.add(AbilityL);

				JButton AbilityUp = new JButton("Up");
				AbilityUp.addActionListener(m -> {
					try {
						game.castAbility(a.get(0), Direction.UP);
						update();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Not Enough Resources Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Ability Used Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Clone Not Supported Exception",
								JOptionPane.ERROR_MESSAGE);
					}

				});
				
				Directions.add(AbilityUp);

				JButton AbilityDown = new JButton("Down");
				AbilityDown.addActionListener(f -> {
					try {
						game.castAbility(a.get(0), Direction.DOWN);
						update();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Not Enough Resources Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Ability Used Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Clone Not Supported Exception",
								JOptionPane.ERROR_MESSAGE);
					}
				});
				Directions.add(AbilityDown);

			}
			
			if (a.get(0).getCastArea().equals(AreaOfEffect.SINGLETARGET)) {
				JOptionPane.showMessageDialog(null,
						"Please Choose a cell",null,
						JOptionPane.INFORMATION_MESSAGE);
				Ability b= a.get(0);
			
				for(int i = 0; i<5; i++) {
					for(int j=0;j<5;j++) {
						int x=i;
						int y=j;
						boardbtn[i][j].addMouseListener(new MouseAdapter() {
							public void mouseClicked(MouseEvent e) {
								if(e.getSource()==boardbtn[x][y]) {
									try {
										game.castAbility(b,x,y);
										update();
									}
								 catch (NotEnoughResourcesException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Not Enough Resources Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
									return;
								} catch (AbilityUseException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Ability Used Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
									return;
								} catch (CloneNotSupportedException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Clone Not Supported Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
									return;
								} catch (InvalidTargetException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Invalid Target Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
								}
								
							}
						}
						});
					}
				}
				
				for(int z=0;z<5;z++) {
					for(int n=0;n<5;n++) {
						boardbtn[z][n].addActionListener(null);
						
					}
				}
			}
		});
		p1l.add(ab1);

		ab2 = new JButton(a.get(1).getName());
		ab2.setPreferredSize(new Dimension(100, 100));
		ab2.setBounds(500, board.getHeight(), 100, 100);
		ab2.addActionListener(a1 -> {
			if (a.get(1).getCastArea().equals(AreaOfEffect.TEAMTARGET)
					|| a.get(1).getCastArea().equals(AreaOfEffect.SELFTARGET)
					|| (a.get(1).getCastArea().equals(AreaOfEffect.SURROUND))) {

				try {
					game.castAbility(a.get(1));
					update();

				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Not Enough Resources Exception",
							JOptionPane.ERROR_MESSAGE);
				} catch (AbilityUseException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Ability Used Exception", JOptionPane.ERROR_MESSAGE);
				} catch (CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Clone Not Supported Exception",
							JOptionPane.ERROR_MESSAGE);
				}

			}
			if (a.get(1).getCastArea().equals(AreaOfEffect.DIRECTIONAL)) {

				JFrame Directions = new JFrame("Directions");
				Directions.setPreferredSize(new Dimension(500, 500));
				Directions.setSize(500, 500);
				Directions.setTitle("Direction of Ability");
				Directions.setLayout(new GridLayout(2, 2));
				Directions.setVisible(true);
				JButton AbilityR = new JButton("Right");
				AbilityR.addActionListener(d -> {
					try {
						game.castAbility(a.get(1), Direction.RIGHT);
						update();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Not Enough Resources Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Ability Used Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Clone Not Supported Exception",
								JOptionPane.ERROR_MESSAGE);
					}

				});
				
				Directions.add(AbilityR);

				JButton AbilityL = new JButton("Left");
				AbilityL.addActionListener(l -> {
					try {
						game.castAbility(a.get(1), Direction.LEFT);
						update();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Not Enough Resources Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Ability Used Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Clone Not Supported Exception",
								JOptionPane.ERROR_MESSAGE);
					}

				});
				
				Directions.add(AbilityL);

				JButton AbilityUp = new JButton("Up");
				AbilityUp.addActionListener(m -> {
					try {
						game.castAbility(a.get(1), Direction.UP);
						update();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Not Enough Resources Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Ability Used Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Clone Not Supported Exception",
								JOptionPane.ERROR_MESSAGE);
					}

				});
				
				Directions.add(AbilityUp);

				JButton AbilityDown = new JButton("Down");
				AbilityDown.addActionListener(f -> {
					try {
						game.castAbility(a.get(1), Direction.DOWN);
						update();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Not Enough Resources Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Ability Used Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Clone Not Supported Exception",
								JOptionPane.ERROR_MESSAGE);
					}
				});
				Directions.add(AbilityDown);

			}
			if (a.get(1).getCastArea().equals(AreaOfEffect.SINGLETARGET)) {
				JOptionPane.showMessageDialog(null,
						"Please Choose a cell",null,
						JOptionPane.INFORMATION_MESSAGE);
				Ability b= a.get(1);
				for(int i = 0; i<5; i++) {
					for(int j=0;j<5;j++) {
						int x=i;
						int y=j;
						boardbtn[i][j].addMouseListener(new MouseAdapter() {
							public void mouseClicked(MouseEvent e) {
								if(e.getSource()==boardbtn[x][y]) {
									try {
										game.castAbility(b,x,y);
										update();
									}
								 catch (NotEnoughResourcesException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Not Enough Resources Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
									return;
								} catch (AbilityUseException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Ability Used Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
									return;
								} catch (CloneNotSupportedException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Clone Not Supported Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
									return;
								} catch (InvalidTargetException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Invalid Target Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
								}
								
							}
						}
						});
					}
				}
				
				for(int z=0;z<5;z++) {
					for(int n=0;n<5;n++) {
						boardbtn[z][n].addActionListener(null);
						
					}
				}
			}
		});
		p1l.add(ab2);

		ab3 = new JButton(a.get(2).getName());
		ab3.setPreferredSize(new Dimension(100, 100));
		ab3.setBounds(500, board.getHeight(), 100, 100);
		ab3.addActionListener(a1 -> {
			if (a.get(2).getCastArea().equals(AreaOfEffect.TEAMTARGET)
					|| a.get(2).getCastArea().equals(AreaOfEffect.SELFTARGET)
					|| (a.get(2).getCastArea().equals(AreaOfEffect.SURROUND))) {

				try {
					game.castAbility(a.get(2));
					update();

				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Not Enough Resources Exception",
							JOptionPane.ERROR_MESSAGE);
				} catch (AbilityUseException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Ability Used Exception", JOptionPane.ERROR_MESSAGE);
				} catch (CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(),
							"Clone Not Supported Exception",
							JOptionPane.ERROR_MESSAGE);
				}

			}
			if (a.get(2).getCastArea().equals(AreaOfEffect.DIRECTIONAL)) {

				JFrame Directions = new JFrame("Directions");
				Directions.setPreferredSize(new Dimension(500, 500));
				Directions.setSize(500, 500);
				Directions.setTitle("Direction of Ability");
				Directions.setLayout(new GridLayout(2, 2));
				Directions.setVisible(true);
				JButton AbilityR = new JButton("Right");
				AbilityR.addActionListener(d -> {
					try {
						game.castAbility(a.get(2), Direction.RIGHT);
						update();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Not Enough Resources Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Ability Used Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Clone Not Supported Exception",
								JOptionPane.ERROR_MESSAGE);
					}

				});
				
				Directions.add(AbilityR);

				JButton AbilityL = new JButton("Left");
				AbilityL.addActionListener(l -> {
					try {
						game.castAbility(a.get(2), Direction.LEFT);
						update();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Not Enough Resources Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Ability Used Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Clone Not Supported Exception",
								JOptionPane.ERROR_MESSAGE);
					}

				});
				
				Directions.add(AbilityL);

				JButton AbilityUp = new JButton("Up");
				AbilityUp.addActionListener(m -> {
					try {
						game.castAbility(a.get(2), Direction.UP);
						update();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Not Enough Resources Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Ability Used Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Clone Not Supported Exception",
								JOptionPane.ERROR_MESSAGE);
					}

				});
				
				Directions.add(AbilityUp);

				JButton AbilityDown = new JButton("Down");
				AbilityDown.addActionListener(f -> {
					try {
						game.castAbility(a.get(2), Direction.DOWN);
						update();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Not Enough Resources Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Ability Used Exception",
								JOptionPane.ERROR_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(),
								"Clone Not Supported Exception",
								JOptionPane.ERROR_MESSAGE);
					}
				});
				Directions.add(AbilityDown);
			}
			else if (a.get(2).getCastArea().equals(AreaOfEffect.SINGLETARGET)) {
				JOptionPane.showMessageDialog(null,
						"Please Choose a cell",null,
						JOptionPane.INFORMATION_MESSAGE);
				Ability b= a.get(2);
			
				for(int i = 0; i<5; i++) {
					for(int j=0;j<5;j++) {
						int x=i;
						int y=j;
						boardbtn[i][j].addMouseListener(new MouseAdapter() {
							public void mouseClicked(MouseEvent e) {
								if(e.getSource()==boardbtn[x][y]) {
									try {
										game.castAbility(b,x,y);
										update();
									}
								 catch (NotEnoughResourcesException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Not Enough Resources Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
									return;
								} catch (AbilityUseException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Ability Used Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
									return;
								} catch (CloneNotSupportedException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Clone Not Supported Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
									return;
								} catch (InvalidTargetException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Invalid Target Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
								}
								
							}
						}
						});
					}
				}
				
				for(int z=0;z<5;z++) {
					for(int n=0;n<5;n++) {
						boardbtn[z][n].addActionListener(null);
						
					}
				}
			}
		});
		p1l.add(ab3); 
		boolean disarm= false;
		for(int i=0;i<cur.getAppliedEffects().size();i++) {
			if(cur.getAppliedEffects().get(i) instanceof Disarm) {
				disarm= true;
			    break;}
		}
		if(disarm) {
			ab4 = new JButton(a.get(3).getName());
			ab4.setPreferredSize(new Dimension(100, 100));
			ab4.setBounds(500, board.getHeight(), 100, 100);
			ab4.addActionListener(a1-> {
				JOptionPane.showMessageDialog(null,
						"Please Choose a cell",null,
						JOptionPane.INFORMATION_MESSAGE);
				Ability b= a.get(3);
				for(int i = 0; i<5; i++) {
					for(int j=0;j<5;j++) {
						int x=i;
						int y=j;
						boardbtn[i][j].addMouseListener(new MouseAdapter() {
							public void mouseClicked(MouseEvent e) {
								if(e.getSource()==boardbtn[x][y]) {
									try {
										game.castAbility(b,x,y);
										update();
									}
								 catch (NotEnoughResourcesException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Not Enough Resources Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
									return;
								} catch (AbilityUseException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Ability Used Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
									return;
								} catch (CloneNotSupportedException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Clone Not Supported Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
									return;
								} catch (InvalidTargetException e1) {
									JOptionPane.showMessageDialog(null, e1.getMessage(),
											"Invalid Target Exception",
											JOptionPane.ERROR_MESSAGE);
									e1.printStackTrace();
								}
								
							}
						}
						});
					}
				}
				
				for(int z=0;z<5;z++) {
					for(int n=0;n<5;n++) {
						boardbtn[z][n].addActionListener(null);
						
					}
				} 
				
				
			});
			p1l.add(ab4);
			
			
		}
		
	
		

		
		JButton EndTurn = new JButton();
		EndTurn.setText("End Turn");
		EndTurn.setPreferredSize(new Dimension(100, 100));
		EndTurn.setBounds(500, board.getHeight(), 100, 100);
		EndTurn.addActionListener(u -> {
			try {
				int cx = game.getCurrentChampion().getLocation().x;
				int cy = game.getCurrentChampion().getLocation().y;
				boardbtn[cx][cy].setBackground(Color.RED);
				game.endTurn();
				int xx = game.getCurrentChampion().getLocation().x;
				int yy = game.getCurrentChampion().getLocation().y;
				boardbtn[xx][yy].setBackground(Color.green);
				/*p1l.remove(ab1);
				p1l.remove(ab2);
				p1l.remove(ab3);
				ab1= new JButton(game.getCurrentChampion().getAbilities().get(0)
						.getName());
				ab2= new JButton(game.getCurrentChampion().getAbilities().get(1)
						.getName());
				ab3= new JButton(game.getCurrentChampion().getAbilities().get(2)
						.getName());
				ab1.setPreferredSize(new Dimension(100, 100));
				ab1.setBounds(500, board.getHeight(), 100, 100);
				ab2.setPreferredSize(new Dimension(100, 100));
				ab2.setBounds(500, board.getHeight(), 100, 100);
				ab3.setPreferredSize(new Dimension(100, 100));
				ab3.setBounds(500, board.getHeight(), 100, 100);
				p1l.add(ab1);
				p1l.add(ab2);
				p1l.add(ab3);*/
				cur = game.getCurrentChampion();
				a = cur.getAbilities();
				this.update();

			} catch (Exception e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(),
						"Can't End Turn", JOptionPane.ERROR_MESSAGE);
			}
		});
		
		JButton LeaderAbility = new JButton("Use Leader ability");
		LeaderAbility.setPreferredSize(new Dimension(100, 100));
		LeaderAbility.setBounds(100, board.getHeight(), 100, 100);
		
		LeaderAbility.addActionListener(e -> {
			try {
				game.useLeaderAbility();
				update();
			} catch (LeaderAbilityAlreadyUsedException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(),
						"Leader Ability Already Used Exception",
						JOptionPane.ERROR_MESSAGE);

			} catch (LeaderNotCurrentException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(),
						"Leader Not Current Exception",
						JOptionPane.ERROR_MESSAGE);

			}
		});
		String s1= "";
		turnorder1= new PriorityQueue(game.getTurnOrder().size());
		Champion c=(Champion) game.getTurnOrder().remove();
		
		while(!game.getTurnOrder().isEmpty()) {
			s1= s1+ ", "+((Champion)game.getTurnOrder().peekMin()).getName();
			turnorder1.insert(game.getTurnOrder().remove());
		}
		while(!turnorder1.isEmpty()) {
			game.getTurnOrder().insert(turnorder1.remove());
		}
		game.getTurnOrder().insert(c);
	
		turntext= new JLabel();
		turntext.setText("Next Champions: "+s1);
		turntext.setPreferredSize(new Dimension(400,100));

		
		p1l.setBounds(200, board.getHeight(), 400, 300);
		
		p1l.add(LeaderAbility);
		p1l.add(move);
		p1l.add(attack);
		p1l.add(EndTurn);
		p1l.add(turntext);
		
		p1l.setLayout(new FlowLayout(FlowLayout.LEADING));
		panel.add(p1l, BorderLayout.SOUTH);

		this.revalidate();
		this.repaint();
		this.setVisible(true);

	}

	public void gameOver() {
		this.dispose();
		JFrame winf=new JFrame();
		winf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		winf.setVisible(true);
		winf.setSize(1500, 750);
		winf.setTitle("Marvel: Ultimate War");
		winf.setLayout(new BorderLayout());
		JLabel win=new JLabel();
		win.setBounds(0, 0, 1500, 750);
		win.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 50));
		if (game.checkGameOver() != null)
			win.setText(game.checkGameOver().getName() + " is the WINNER");
		winf.add(win);
		this.revalidate();
		this.repaint();

	}

	public static void main(String[] args) {
		new Startgame();

	}

}
